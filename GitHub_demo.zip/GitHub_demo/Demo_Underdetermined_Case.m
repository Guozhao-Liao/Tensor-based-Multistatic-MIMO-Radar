


% Experiment: Underdetermined Case.

%   Authors:    Guo-Zhao Liao              (guozhao@mail.dlut.edu.cn)
%               Xiao-Feng Gong             (xfgong@dlut.edu.cn)
%               Wei Liu                    (wei2.liu@polyu.edu.hk)
%               Hing Cheung So             (hcso@ee.cityu.edu.hk)
%
%   Version History:
%       - 2025/03/14    GZ      Initial version.
%
%   References: 
%   [1] G.-Z. Liao, X.-F. Gong, W. Liu, and H. C. So
%       Target localization with a coprime multistatic mimo radar via
%       coupled canonical polyadic decomposition based on joint evd
%       In ICASSP 2025 - 2025 IEEE International Conference on Acoustics, 
%       Speech and Signal Processing (ICASSP), 2025, pp. 1–5.

%% Coprime L-shaped receive arrays:
clear; clc
%% Receive array 1
gen_list2 =   {[4,7]; [4,7]};                          % coprime rate along the x-axis and y-axis for site 2
gen_max2 = {[12, 21]; [12, 21]};                       % endpoint of each rate for site 2  
nla{1} = setup_simple_nla(gen_list2, gen_max2);
length(nla{1}.sensors{1})+length(nla{1}.sensors{2})-1

%% Receive array 2
gen_list3 =   {[4,7]; [4,7]};                          % coprime rate along the x-axis and y-axis for site 2
gen_max3 ={[12, 21]; [12, 21]};                        % endpoint of each rate for site 2  
nla{2} = setup_simple_nla(gen_list3, gen_max3);

%% Receive array 3
gen_list4 =   {[4,7]; [4,7]};                          % coprime rate along the x-axis and y-axis for site 2
gen_max4 = {[12, 21]; [12, 21]};                       % endpoint of each rate for site 2  
nla{3} = setup_simple_nla(gen_list4, gen_max4);

%% Transmitter
gen_list1 =   {[4,7]; [4,7]};                             % coprime rate along the x-axis and y-axis for site 2
gen_max1 = {[16, 14]; [16, 14]};                        % endpoint of each rate for site 2 
nla{4} = setup_simple_nla(gen_list1, gen_max1);
length(nla{4}.sensors{1})*length(nla{4}.sensors{2})
%% 

cfg.t{1} = nla{4}.sensors;
cfg.r{1} = nla{1}.sensors;
cfg.r{2} = nla{2}.sensors;
cfg.r{3} = nla{3}.sensors;

P = size(cfg.t,2);
Q = size(cfg.r,2);

%% Number of array elements
Nt = zeros(1,P);
for p = 1:P
  Nt(1,p) = length(cfg.t{p}{1})*length(cfg.t{p}{2});       
end
Nr = zeros(1,Q);
for q = 1:Q
 Nr(1,q) = length(cfg.r{q}{1})+length(cfg.r{q}{2})-1;
end

cfg.t_subary = zeros(1,P)+3;    %% 
cfg.r_subary = zeros(1,Q)+3;    %% 

cfg.nla = nla;
cfg.t_ary = 1;
cfg.r_ary = 1;
cfg.t_subary = zeros(1,P)+4;       %% '5' is Coprime Planar Arrays, '6' is Coprime L-shaped Arrays, and '4' is Uniform Planar Array.
cfg.r_subary = zeros(1,Q)+6;       %% '5' is Coprime Planar Arrays, '6' is Coprime L-shaped Arrays, and '4' is Uniform Planar Array. 
ary_d.t_subary = zeros(1,P)+1/2;   %% Transmit subarrays, inter-element spacing
ary_d.r_subary = zeros(1,Q)+1/2;   %% Receive subarrays, inter-element spacing
ary_d.t_ary = 8e3;
ary_d.r_ary = 8e3;


t_vec = [0,-8000,0];
r_vec = [0,8000,0];
ary_p = [t_vec;r_vec];
R = 25;
K = 20;

%% random
% numTargets = R;
% xRange = [-7000,7000];
% yRange = [-7000, 7000];
% zRange = [4000, 8000];
% x = xRange(1) + (xRange(2) - xRange(1)) * rand(numTargets, 1);
% y = yRange(1) + (yRange(2) - yRange(1)) * rand(numTargets, 1);
% z = zRange(1) + (zRange(2) - zRange(1)) * rand(numTargets, 1);
% tgt_p = [x, y, z];  

tgt_p = [3418.20075107616	-259.674302083120	5857.33206329426
1061.92659139874	4567.47703386975	4595.30332973858
126.789582045870	-6071.65898993010	5481.66550035117
5035.69600019000	6551.62957193549	4954.79908426975
-476.492684432360	-3480.72704069626	5597.47271504559
2318.39536298563	2744.92565454297	6408.85311784512
3386.42326932284	-5044.86122301491	6331.80398569791
-3550.27191323268	-4528.06791104902	7425.75633866410
-6528.83783484116	-1968.11974566746	7185.15664241234
4202.58262193218	-5876.06679130340	4363.06010737863
-4860.05224254247	-4887.32253563717	4857.29653082847
-792.818480403616	-821.191549554679	5785.43730680268
2419.86004263617	3112.93810913598	5894.09718459958
2708.49146509155	3414.24101541452	4131.93782334593
6304.67380422802	-5927.51011291411	4462.75608645666
-6414.31691154797	1082.46404009367	4415.99871695387
-4153.70828966314	-680.978673536625	4237.54632332219
-3645.57299568289	1254.09398352652	4724.88843701232
-5957.72900096495	-1649.60075561626	4113.34129928228
2337.88754712262	-4101.38558189479	7585.62677574027
1871.16110066578	-2895.41612843853	4034.91734935523
-3839.10878307011	-4179.14570998090	7064.72892038834
1203.65452200851	4766.68714505556	5952.46113540097
-732.583052638025	-6313.71470176996	6463.92759358767
5407.34630967286	-2281.08660387851	7396.35435490516];

snr_sequence = 0:2:30;
Mont = 200;

swerling_flag = 0;
wf = 4;  
wg = [];
T = 64;  
tol_sdf = 1e-6;
maxit_sdf = 5000;
ninit_sdf = 1;
niter_sdf = 1;
sdf_opt = 1;
acc = 1;
op  = 2;
rad = pi/180;        
degreed = 180/pi;   
algo_number = 1;
N_length = length(snr_sequence);
snr_index = 1;

for i = 1:N_length
       
snr = snr_sequence(i);

parfor iter = 1:Mont
% for iter = 1:Mont
   [X, ~, ~, C, st,DOD, DOA, ary_K,A,B] =  f_DATA_MIMO_RADAR_Multiple_receive_arrays_multirate(Nt, Nr, cfg, ary_d, ary_p, tgt_p, swerling_flag, wf, wg, T, K, snr);
X_ = cell(Q,1);
for qq = 1:Q   
  X_{qq} = permute(X{qq},[1,3,2]);     
end

for  algo = 1:algo_number
switch algo

case 1
[errAngle_mean,DOA_RMSE_mean,~,~,~,~,running_time] = f_my_CCPD_Multirate_JEVD_ALG_2_L_shaped(X_,nla,K,R,ary_K,Q,tgt_p,DOA,rad,Nr);
 errAngleMean(iter,algo) = errAngle_mean;               
 RMSE_matrix(iter,algo) = DOA_RMSE_mean;
 running_time_matrix(iter,algo) = running_time;
end


end
end

errAngleMean_mean(snr_index,:) = mean(errAngleMean,1);          
RMSE_matrix_sqrt_mean(snr_index,:) = sqrt(mean(RMSE_matrix,1));
running_time_matrix_mean(snr_index,:) = mean(running_time_matrix,1);

snr_index = snr_index + 1;
end

%% MAE
figure()
grid on;
semilogy(snr_sequence,errAngleMean_mean(:,1),'-s','Color','r','LineWidth', 1.5,'MarkerEdgeColor','r','MarkerFaceColor','none','MarkerSize',8);
hold on;
xlabel('SNR [dB]','FontSize', 12)
ylabel('MAE [deg]','FontSize', 12)
legend('C-CPD-JEVD(Proposed method)','FontSize', 12,'LineWidth',1);

%% RMSE
figure()
grid on;
semilogy(snr_sequence,RMSE_matrix_sqrt_mean(:,1),'-s','Color','r','LineWidth', 1.5,'MarkerEdgeColor','r','MarkerFaceColor','none','MarkerSize',8);
hold on;
xlabel('SNR [dB]','FontSize', 12)
ylabel('RMSE [deg]','FontSize', 12)
legend('C-CPD-JEVD(Proposed method)','FontSize', 12,'LineWidth',1);

%% time
figure()
grid on;
semilogy(snr_sequence,running_time_matrix_mean(:,1),'-s','Color','r','LineWidth', 1.5,'MarkerEdgeColor','r','MarkerFaceColor','none','MarkerSize',8);
hold on;
xlabel('SNR [dB]','FontSize', 12)
ylabel('Time [s]','FontSize', 12)
legend('C-CPD-JEVD(Proposed method)','FontSize', 12,'LineWidth',1);

