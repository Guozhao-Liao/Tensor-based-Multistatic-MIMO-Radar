


function [Yn,U,V]  = my_mrt_ccpd_tensorgen_L_shaped(X_,nla,K,R,Nr)
options.Compression = 0;
Mx = length(X_);
sz = cell(Mx,1);
T_mtx = [];
N_sub = 0;
for mm = 1:Mx
    N_sub = N_sub+sum(cellfun(@numel, nla{mm}.subulas));
    sz{mm} = size(X_{mm});
    T_mtx = [T_mtx;reshape(X_{mm},[prod(sz{mm}(1:end-1)),sz{mm}(end)])];  
end

[U, Ss, V] = svd(T_mtx);
Ss = Ss(1:R, 1:R);
U = U(:, 1:R)*Ss;    
V = V(:, 1:R);       

offset = 0;
Yn = cell(1, N_sub);
U_kr = cell(1,Mx);
index =1;
for mm = 1:Mx
    row_range = offset+1 : offset+prod(sz{mm}(1:end-1));
    offset = offset + prod(sz{mm}(1:end-1));             
    U_tmp = U(row_range,:);                       
    U_kr{mm} = U_tmp;                              
 
    Y = reshape(U_tmp, length(nla{mm}.sensors{1})+length(nla{mm}.sensors{2})-1,K,R);   
Y_zs = size(Y);
N_xy = ceil(Nr(mm)/2);
    for xy = 1:2  
      if xy==1
        Y_1 = reshape(Y(N_xy:-1:1,:,:), N_xy,Y_zs(2),Y_zs(3)); 
      else
        Y_1 = reshape(Y(N_xy:end,:,:), N_xy,Y_zs(2),Y_zs(3));
      end

        subulas = nla{mm}.subulas{xy};   
        sensors = nla{mm}.sensors{xy};  
        for sula = 1:length(subulas)
                subula = subulas{sula};
                [~, idx] = intersect(sensors, subula ,'stable');   
                % spatial smoothing
                Y1 = Y_1(idx(1:end-1), :, :);    
                Y2 = Y_1(idx(2:end), :, :);              
                Y1 = reshape(Y1, [size(Y1, 1)*size(Y1, 2), size(Y1, 3)]);   %% 
                Y2 = reshape(Y2, [size(Y2, 1)*size(Y2, 2), size(Y2, 3)]);   %% 
               
                if options.Compression && (size(Y1, 1)*size(Y1, 2)*2 > R)
                    W1 = [Y1, Y2];
                    [UW1,~,~] = svd(W1);
                    dm = min(R, size(W1, 1));
                    UW1 = UW1(:, 1:dm);
                    Y1 = UW1'*W1(:,1:end/2);
                    Y2 = UW1'*W1(:,end/2+1:end);
                end
                Yi(:, 1, :) = Y1;
                Yi(:, 2, :) = Y2;
                Yn{index} = Yi;    
      
                index = index + 1;    
                clear Yi;
        end
                      
    end
    
end    

end