 

function [X, t_str, r_str, rcs, st, DOD, DOA, ary_K,A,B] =  f_DATA_MIMO_RADAR_Multiple_receive_arrays_multirate(Nt, Nr, cfg, ary_d, ary_p, tgt_p, swerling_flag, wf, wg, T, K, snr)
%% Input
%% Array Parameters
% Nt: A vector that contains the number of each transmitting subarray. The
%     length of Nt denotes the number of subarrays, and Nt(k) denotes the
%     number of sensors in the kth transmitting subarray.
% Nr: A vector that contains the number of each receiving subarray. The
%     length of Nr denotes the number of subarrays, and Nr(k) denotes the
%     number of sensors in the kth transmitting subarray.
% cfg: a structure that contains the array configuration of each transmitting
%      and receiving subarray.
%    .t_ary: configuration of all the transmitting subarrays
%    .r_ary: configuration of all the receiving subarrays
%    .t_subary: a vector that contains the configuration of each transmitting
%               subarray
%    .r_subary: a vector that contains the configuration of each receiving
%               subarray
%    for each value in cfg: 1: Uniform Linear Array
%                           2: Uniform Circular Array
%                           3: Uniform L-shaped Array
% ary_d: a structure that contains the interspacing between subarrays and interspacing
%        between sensors in each subarray.
%    .t_ary: the interspacing between transmitting subarrays;
%    .r_ary: the interspacing between receiving subarrays;
%    .t_subary: a vector that contains the interspacing between sensors in each
%               transmitting subarray;
%    .r_subary: a vector that contains the interspacing between sensors in each
%               receiving subarray;
% ary_p: a 2 by 3 matrix that contains the coordinates of the centers of
%        transmitting array and the receiving array.
%     ary_p(1,1:3) denotes the cooridnates of the center of the
%                  transmitting array
%     ary_p(2,1:3) denotes the cooridnates of the center of the
%                  receiving array
%% Target Parameters
% tgt_p: an R by 3 matrix that contains the coordinates of targets.
%     e.g. tgt_p(r,1:3) denotes the coordinates of the rth target
% swerling_flag: 1 - of type swerling 1
%                2 - of type swerling 2
%% Waveform Parameters
% wf: options for the generation of transmitting waveforms within a pulse
%     period
%   1 - the waveforms transmitted from different sensors are mutually
%       orthogonal;
%   2 - the waveforms transmitted from different subarrays are mutually
%       orthogonal, while those transmitted from different sensors within 
%       the same subarray are mutually dependent;
%   3 - the transmitting subarrays are split into several groups. The
%       transmitted waveforms from subarrays within the same group are
%       mutually dependent, while those from subarrays of different groups
%       are mutually independent. In this case, the additional parameter wg
%       will be used to indicate how the subarrays are grouped.
% wg: available only when wf == 3. It is a vector holding the number of
%     subarrays in each group, within which the transmitting waveforms are
%     mutually dependent. It is assumed that the neighbouring subarrays are
%     grouped. E.g. wg = [2;3;2], indicates that the first group contains
%     the 1st and 2nd subarrays, the second group contains the 3rd, 4th,
%     and 5th subarrays, the third group contains the 6th and 7th subarrays.
% T: number of time samples of the transmitted waveforms within a pulse
%    period
% K: number of transmitted pulses
%% Noise Parameters
% snr: signal-to-noise ratio

%% Output
% X: a cell holding the MIMO Radar output signals in each receiving
%    subarray
% t_str: a P by 1 cell holding the matrix of steering vectors of each transmitting 
%    subarray. P is the number of transmitting subarrays.
% r_str: a Q by 1 cell holding the matrix of steering vectors of each receiving 
%    subarray. Q is the number of receiving subarrays.
% rcs: a P by Q cell holding the matrix of target RCS coefficients
%    associated with each transmitting and receiving subarray
% st: a P by 1 cell holding the transmitting waveform of each transmitting
%    subarray
% DOD: a P by 1 cell. Each cell holds a R by 3 direction-of-departure (DOD) 
%      matrix associated with each transmitting subarray, of which each row
%      holds the poyntine vector associated with the DOD from that transmitting 
%      subarray to each target.
% DOA: a Q by 1 cell. Each cell holds a R by 3 direction-of-arrival (DOA) 
%      matrix associated with each receiving subarray, of which each row holds
%      the poyntine vector associated with the DOA from each target to that
%      receiving subarray.
% ary_K: a structure holding the position of each transmitting and
%        receiving subarray.
%      .t_ary: a P by 3 matrix of which each row holds the coordinates of
%      the center position of each transmitting subarray
%      .r_ary: a Q by 3 matrix of which each row holds the coordinates of
%      the center position of each receiving subarray
%      .t_subary: a P by 1 cell. Each cell holds a coordinate matrix associated 
%      with each transmitting subarray, of which each row holds the coordinates 
%      of each sensor in that subarray.
%      .r_subary: a Q by 1 cell. Each cell holds a coordinate matrix associated 
%      with each receiving subarray, of which each row holds the coordinates of 
%      each sensor in that subarray.
% info: a structure holding the basic information of the generated dataset
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Generate the coordinates of each transmitting and receiving sensor 
%% in each transmitting and receiving subarray
% Coordinates of the transmitting and receiving subarrays
P = length(Nt); % number of transmitting subarrays
Q = length(Nr); % number of receiving subarrays

K_t_ary = f_ary_cfg_big(cfg.t_ary,P,1);           
K_r_ary = f_ary_cfg_big(cfg.r_ary,Q,1);           
K_t_ary = K_t_ary* ary_d.t_ary + repmat(ary_p(1,:),[P,1]);   
K_r_ary = K_r_ary* ary_d.r_ary + repmat(ary_p(2,:),[Q,1]);   
ary_K.t_ary = K_t_ary;
ary_K.r_ary = K_r_ary;
% Coordinates of the sensors in each transmitting subarray
K_t_subary = cell(P,1);
Kfg_t_subary = cell(P,1);
K_r_subary = cell(Q,1);
Kfg_r_subary = cell(Q,1);
for pp = 1:P
    K_t_subary{pp} = f_ary_cfg(cfg.t_subary(pp),cfg.t{pp},Nt(pp),1);  
    K_t_subary{pp} = K_t_subary{pp} * ary_d.t_subary(pp);   
    Kfg_t_subary{pp} = K_t_subary{pp};
    K_t_subary{pp} = K_t_subary{pp} + repmat(K_t_ary(pp,:),[Nt(pp),1]);
end
for qq = 1:Q
    K_r_subary{qq} = f_ary_cfg(cfg.r_subary(qq),cfg.r{qq},Nr(qq),1);
    K_r_subary{qq} = K_r_subary{qq} * ary_d.r_subary(qq);  
    Kfg_r_subary{qq} = K_r_subary{qq};
    K_r_subary{qq} = K_r_subary{qq} + repmat(K_r_ary(qq,:),[Nr(qq),1]);
end
ary_K.t_ary = K_t_ary;
ary_K.r_ary = K_r_ary;
ary_K.t_subary = K_t_subary;
ary_K.r_subary = K_r_subary;
ary_K.Kfg_t_subary = Kfg_t_subary;
ary_K.Kfg_r_subary = Kfg_r_subary;
% Now K_t_subarray (P by 1 cell) holds the coordinates of all the sensors 
% in each transmitting subarray; K_r_subarray (Q by 1 cell) holds the 
% coordinates of all the sensors in each receiving subarray; 
% K_t_ary (P by 3 matrix) holds the coordinates of the center of each
% transmitting subarray; K_r_ary (Q by 3 matrix) holds the coordinates of 
% the center of each receiving subarray.
%% Calculate the direction of departure (DOD) from each transmitting
%% subarray to the target, and the direction of arrival (DOA) from 
%% each target to each receiving subarray
DOD = cell(P,1);
DOA = cell(Q,1);
R = size(tgt_p,1);
for pp = 1:P
    DOD{pp} = zeros(3,R);
    for rr = 1:R
        DOD{pp}(:,rr) = f_dir_vec(K_t_ary(pp,:),tgt_p(rr,:));  %%发射阵坐标，接收阵坐标
    end
end
for qq = 1:Q
    DOA{qq} = zeros(3,R);
    for rr = 1:R
        DOA{qq}(:,rr) = f_dir_vec(tgt_p(rr,:),K_r_ary(qq,:));
    end
end
%% Calculate the steering vectors for both transmitting and receiving 
%% subarrays
t_str = cell(P,1);
r_str = cell(Q,1);
for pp = 1:P
    t_str{pp} = f_space_steer(DOD{pp},Kfg_t_subary{pp});  
end
for qq = 1:Q
    r_str{qq} = f_space_steer(DOA{qq},Kfg_r_subary{qq});  
end
%% Generate the RCS associated with each pair of transmitting and 
%% receiving subarrays
rcs = cell(Q,P);
switch swerling_flag
    case 0
        for pp = 1:Q
            for qq = 1:P
                rcs{pp,qq} = randn(K,R) + 1i*randn(K,R);
            end
        end
    case 1
        % pending
end

%% Construct the transmitting waveforms
st = cell(P,1);
t_st = randn(sum(Nt),T) + 1i*randn(sum(Nt),T);
t_st = orth(t_st.');
t_st=t_st.';
% Case 1: refers to a classic MIMO model holding mutually independent signals within any constructed subarray;
% Case 2: a developed MIMO model which has relaxed the assumed strict condition over the 1st case; 
% Case 3: a complex situation whose conditions are relaxed further compared to the two previous situations
switch wf
    case 1
        offset = 1;
        for pp = 1:P
            st{pp} = t_st(offset:offset+Nt(pp)-1,:);
            offset = offset + Nt(pp);
        end
    case 2
        offset = 1;
        for pp = 1:P
            t_mtx = randn(Nt(pp)) + 1i*randn(Nt(pp));
            st{pp} = t_mtx * t_st(offset:offset+Nt(pp)-1,:);
            offset = offset + Nt(pp);
        end
    case 3
        offset = 1;
        offset_ = 1;
        for pp = 1:length(wg)
            ind = [offset_:(offset_+wg(pp)-1)];
            offset_ = offset_ + wg(pp);
            t_mtx = randn(sum(Nt(ind))) + 1i*randn(sum(Nt(ind)));
            t_st(offset:offset+sum(Nt(ind))-1,:) = t_mtx * t_st(offset:offset+sum(Nt(ind))-1,:);
            offset = offset + sum(Nt(ind));
        end
        offset = 1;
        for pp = 1:P            
            st{pp} = t_st(offset:offset+Nt(pp)-1,:);
            offset = offset + Nt(pp);
        end
     case 4    
        for pp = 1:P
%             t_mtx = randn(Nt(pp)) + 1i*randn(Nt(pp));
            st{pp} =randn(Nt(pp),T) + 1i*randn(Nt(pp),T);
%             offset = offset + Nt(pp);
        end  
        
end
%% Generate the noise term
% tic
nse = cell(Q,1);
for qq = 1:Q
    nse{qq} = randn(Nr(qq),T,K) + 1i*randn(Nr(qq),T,K);    
end
% toc
%% Construct the MIMO Radar output
% tic
X = cell(Q,1);
Ps = 1;                                                            % signal power                                                                              
Pn = Ps/10^(snr/20);  

for qq = 1:Q
    X{qq} = zeros(Nr(qq),T,K);
    for pp = 1:P
        U{1} = r_str{qq};
        U{2} = st{pp}.'*t_str{pp};
        U{3} = rcs{qq,pp};
        A{qq} =  r_str{qq};
%         B{pp} =  t_str{pp};
        B{pp} =  U{2};
%         temp_x = f_kr(U{1},U{3})*U{2}.';
%         temp_x = reshape(temp_x,[K,Nr(qq),T]);
%         temp_x = permute(temp_x,[2,3,1]);
        temp_x = cpdgen(U);
        X{qq} = X{qq} + temp_x;
    end
  X{qq} = Ps*X{qq} + Pn*nse{qq};
end

%% Record the information on the setting
end
function K = f_ary_cfg(shape_slct,cfg_tr,N,M)
%% Generate the array configuration
% shape_slct = 1: ULA
% shape_slct = 2: UCA
% shape_slct = 3: L-shaped
% shape_slct = 4: Square
% shape_slct = 5: Multirate Planar Array 
% shape_slct = 6: Multirate L-shaped Array  %% 
% N: number of vector-sensors
% M: number of sensors in one vector-sensor
% position = 0:(N-1);
% N1 = cfg_tr(1);
% N2 = cfg_tr(2);
K=[];
switch shape_slct
    case 1
        position = (position - (N-1)/2);
        for i = 1:N
            K = [K;repmat([position(i),0,0],M,1)];
        end
        K = K;
    case 2
        position = position.*(2*pi/N);
        for i = 1:N
            theta = position(i);
            K = [K;repmat([cos(theta),sin(theta),0],M,1)];
        end
        K = K;
    case 3
        position(round(N/2)+1:end) = position(round(N/2)+1:end)-round(N/2)+1;
        for i = round(N/2):-1:1
            K = [K;repmat([position(i),0,0],M,1)];
        end
        for i = (round(N/2)+1):N
            K = [K;repmat([0,position(i),0],M,1)];
        end
        K = K;
    case 4
        position = 0:(N-1);
        N1 = length(cfg_tr{1});
        N2 = length(cfg_tr{2});
        position(1:N2) = position(1:N2)-round(N2/2)+1;
        K1 = [];
        for i = 1:N2
            K1 = [K1;repmat([position(i),0,0],M,1)];
        end
        K1 = K1;
        K2 = [];
        for i = -1:-1:1-N1
           K2 =[K2;K1+repmat([0,i,0],N2,1)];
        end
        K=[K1;K2];   
        
         case 5
%         position = 0:(N-1); 
        N1 = length(cfg_tr{1});
        N2 = length(cfg_tr{2});    
        position  = zeros(1,N1);     
        position(1:N1) = cfg_tr{1};
        K1 = [];
        for i = 1:N1
            K1 = [K1;repmat([position(i),0,0],M,1)];
        end
        K1 = K1;
        K2 = [];
        for i = 2:N2
           K2 =[K2;K1+repmat([0,cfg_tr{2}(i),0],N2,1)];    
        end
        K=[K1;K2];    
    
          case 6    %% '6' 是 L_shaped_multirate
        N1 = length(cfg_tr{1});
        N2 = length(cfg_tr{2});
        N = N1+N2-1;
        for i = N2:-1:1    
            K = [K;repmat([cfg_tr{1}(i),0,0],M,1)];   
        end
        for i = 2:N1
            K = [K;repmat([0,cfg_tr{2}(i),0],M,1)];
        end
        K = K;        
        
            
end

end

function K = f_ary_cfg_big(shape_slct,N,M)
%% Generate the array configuration
% shape_slct = 1: ULA
% shape_slct = 2: UCA
% shape_slct = 3: L-shaped
% shape_slct = 4: Multirate array
% N: number of vector-sensors
% M: number of sensors in one vector-sensor
position = 0:(N-1);
K=[];
switch shape_slct
    case 1
        position = (position - (N-1)/2);
        for i = 1:N
            K = [K;repmat([position(i),0,0],M,1)];
        end
        K = K;
    case 2
        position = position.*(2*pi/N);
        for i = 1:N
            theta = position(i);
            K = [K;repmat([cos(theta),sin(theta),0],M,1)];
        end
        K = K;
    case 3
        position(round(N/2)+1:end) = position(round(N/2)+1:end)-round(N/2)+1;
        for i = round(N/2):-1:1
            K = [K;repmat([position(i),0,0],M,1)];
        end
        for i = (round(N/2)+1):N
            K = [K;repmat([0,position(i),0],M,1)];
        end
        K = K;        
end
end



function dir_vec_ = f_dir_vec(pos_1,pos_2)
%% Calculate the direction vector from position 1 to position 2
dir_vec = pos_1 - pos_2;
dir_vec = dir_vec / norm(dir_vec);
 [~, ~,dir_vec_] = f_Angle_Judgment(dir_vec);

end
function space_vec = f_space_steer(dir_vec, K)
%% Space steering vector of impinging signals with wavelength d
% phai is the elevation of impinging signals
% sita is the azimuth of impinging signals
% K is the array configuration with interspacings (radius) normalized by fc
space_vec = K * dir_vec;

space_vec = space_vec * 2 * pi * (-1i);
space_vec = exp(space_vec); % N by fbin

end

function [sita, phai, DOA] = f_Angle_Judgment(DOA)
if DOA(3) < 0
    DOA = -DOA;
end
phai = acos(DOA(3));
sp = sin(phai);cp = cos(phai);
cs = DOA(1)/sp;
ss = DOA(2)/sp;

if ss >= 0 % 
    sita = acos(cs);
else
    if cs >= 0 %
        sita = 2*pi + asin(ss);
    else % 
        sita = atan(ss/cs) + pi;
    end
end
end
