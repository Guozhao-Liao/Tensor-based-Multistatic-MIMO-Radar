function tgt_pos = f_ALGO_DOA2POS(ary_pos, p_vec)
%% This function calculate the target positions from DOA estimates and array positions
% ary_pos: a 3 by N matrix that holds in its column the position of the array
% p_vec: 3 by N matrix that holds in its column the DOA with regards to each array
Q = size(ary_pos,2);
mtx_B = zeros(3);
vec_Bv = zeros(3,1);

t_ary_pos_temp=ary_pos;

t_p_z=any(p_vec);
ii=1;
for qq=1:Q
    if  t_p_z(qq)==0
        p_vec(:,ii) = [];
        t_ary_pos_temp(:,ii)=[];
        ii=ii-1;
    end
    ii=ii+1;
end

N = size(p_vec,2);
for nn = 1:N
    t_p = p_vec(:,nn);
    t_B = eye(3) - (t_p * t_p.')/(t_p.' * t_p);
    t_v = t_ary_pos_temp(:,nn);
    t_Bv = t_B * t_v;
    mtx_B = mtx_B + t_B;
    vec_Bv = vec_Bv + t_Bv;
end
tgt_pos = mtx_B\vec_Bv;
end


