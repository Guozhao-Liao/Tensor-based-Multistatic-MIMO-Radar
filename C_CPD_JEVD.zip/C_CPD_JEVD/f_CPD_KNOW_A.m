function [Fac, err] = f_CPD_KNOW_A(T, A, ind)
%% 

t_ind = [ind,setdiff([1:3],ind)];
ten = permute(T,t_ind);
tsize = size(ten);  %%

if numel(tsize)==2
    tsize(3) = 1;
end

mtx = reshape(ten,tsize(1),tsize(2)*tsize(3));  
t_kr = (pinv(A)*mtx).';
R = size(A,2);
Fac_2 = zeros(tsize(2),R);
Fac_3 = zeros(tsize(3),R);
for rr = 1:R
    r1_mtx = reshape(t_kr(:,rr),[tsize(2),tsize(3)]);
    
%     rank(r1_mtx)
    [U,S,V] = svd(r1_mtx);
    Fac_2(:,rr) = U(:,1);
    Fac_3(:,rr) = conj(V(:,1)) * S(1,1);
end
Fac{t_ind(1)} = A;
Fac{t_ind(2)} = Fac_2;
Fac{t_ind(3)} = Fac_3;
err = norm(mtx - A * f_kr(Fac_3,Fac_2).');
err = err / norm(mtx);
end

function K = f_kr(A,B)

[ma,na] = size(A);
[mb,nb] = size(B);

if (na == nb)
    
    % Both inputs full, result is full.
    [ia,ib] = meshgrid(1:ma,1:mb);
    K = zeros(ma*mb,na);
    K = A(ia,:).*B(ib,:);
    
else
    error('The inputs should have the same columns');
end
end