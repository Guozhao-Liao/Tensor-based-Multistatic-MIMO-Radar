


function [errAngle_mean,DOA_RMSE_mean,Yn,V,A_alg,generator,running_time] = f_my_CCPD_Multirate_JEVD_ALG_2_L_shaped(X_,nla,K,R,ary_K,Q,tgt_p,DOA,rad,Nr)
tic

[Yn,~,V] = my_mrt_ccpd_tensorgen_L_shaped(X_,nla,K,R,Nr);

lambda = 1;
[F_jevd, ~, ~,~] = ccpd_jevd(Yn,R,'OnlyReturnF', true,'Compression', ...
                                 false,'lambda',lambda);  %% false  true

B_alg = conj(V)/F_jevd.'; 

generator = cell(Q,1);
DOA_alg = cell(Q,1);
A_alg = cell(Q,1);
for mm = 1:Q
    Fac = f_CPD_KNOW_A(X_{mm},B_alg,3);       

N_xy = ceil(Nr(mm)/2);
    A = Fac{1};
Ax = A(N_xy:-1:1,:);
Ay = A(N_xy:end,:);
AB = kr(Ay,Ax);
    AB_ten = reshape(AB, [N_xy, N_xy, R]);
    [generators, ~] = multirate_mhr_rootfinder(AB_ten, nla{mm});

generator{mm} = generators;

xgen = generators(:,1);
ygen = generators(:,2);   
xgen_angle = angle(xgen)/pi;
ygen_angle = angle(ygen)/pi;
w_1 = ygen_angle./xgen_angle;   %% 
w_2 = sqrt(xgen_angle.^2+ygen_angle.^2); 
theta = pi + atan(w_1) - (atan(w_1)<0)*pi;
phi = abs(asin(w_2).* ((-1).^(angle(w_1) < 0)));   %
doa(1,:) = cos(theta).*sin(phi);
doa(2,:) = sin(theta).*sin(phi);
doa(3,:) = cos(phi);
DOA_alg{mm} = doa;
  A_alg{mm} = AB;
end
                          
tgt_pos_alg = zeros(3,R);
t_p_alg  = cell(1,3);
for q = 1:length(DOA_alg)
    t_p_vec_alg(:,:,q) = DOA_alg{q};
end
                    t_ary_pos = ary_K.r_ary.';   
                    for rr = 1:R
                        t_p_alg{rr} = squeeze(t_p_vec_alg(:,rr,:));
                        tgt_pos_alg(:,rr) = f_ALGO_DOA2POS(t_ary_pos, t_p_alg{rr});
                    end
running_time = toc;
perm_alg = f_rotation_alignment(tgt_p.',tgt_pos_alg,R);
tgt_pos_alg_ = tgt_pos_alg * perm_alg;

        tgt_pos_alg = tgt_pos_alg_;
                    tgt_p_ = tgt_p';
                    
    errAngle = zeros(Q,R);                
                    for m = 1: size(t_ary_pos,2)
                        for rr = 1:R
                            errAngle(m,rr) = acos(dot(t_ary_pos(:,m)-tgt_pos_alg(:,rr),t_ary_pos(:,m)-tgt_p_(:,rr))/(norm(t_ary_pos(:,m)-tgt_pos_alg(:,rr))*norm(t_ary_pos(:,m)- tgt_p_(:,rr))))/pi*180;
                        end
                    end
errAngle_mean = abs(mean(errAngle,'all'));


%DOA
[theta_phi_DOA] = f_algo_DOA2angle(DOA,rad);
[theta_phi_DOA_gu] = f_algo_DOA2angle(DOA_alg,rad);
 
for qq = 1:Q 
    theta_phi_DOA_True = theta_phi_DOA{qq};
    theta_phi_DOA_gu_alg = theta_phi_DOA_gu{qq};
perm_alg = f_rotation_alignment(theta_phi_DOA_True.',theta_phi_DOA_gu_alg.',R);
theta_DOA_gu_ = (theta_phi_DOA_gu_alg.' * perm_alg).';
DOA_RMSE(:,qq) = sum((theta_phi_DOA_True - theta_DOA_gu_).^2,2);
end

DOA_RMSE_mean = abs(mean(DOA_RMSE,'all'));




end