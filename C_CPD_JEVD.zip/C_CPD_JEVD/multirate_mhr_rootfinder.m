function [generators, generators_phase] = multirate_mhr_rootfinder(T, nla)
%MULTIRATE_MHR_ROOTFINDER Calculate multirate Vandermonde tensor generators.
%   [GENERATORS, GENERATORS_PHASE] = MULTIRATE_MHR_ROOTFINDER(T, NLA) 
%   computes, given a tensor T whose first and second factor matrices are
%   multirate Vandermonde matrices, the phase of the unit modulus 
%   generators of these multirate Vandermonde vectors. If the tensor T has
%   frontal slices which are the snapshot measurements of a nonuniform 
%   linear sensor array (NLA), the outer product of the ith columns of the 
%   first and second factor matrices are the contribution from the ith 
%   independent source to the measurements. The phases are computed as the 
%   roots of a real polynomial. The generators are then constructed 
%   as the unit modulus complex number with the previously calculated 
%   phase. The struct nla contains necessary information about the sensor 
%   array:
%    
%       nla.sensors:    contains two cells, one for both the x- and 
%                       y-direction, which contain the sensor positions
%                       along that direction. The first sensor must always
%                       be located at (0, 0). If x is an element of 
%                       nla.sensors{1}, and y is an element of
%                       nla.sensors{2}, there is a sensor located at 
%                       (x, y).
%       nla.subulas:    contains two cells, one for both the x- and 
%                       y-direction, which contain the sub-ULAs in that
%                       direction. Sub-ULAs are uniform linear arrays; 
%                       hence sensors that are regularly spaced.
%
%   An example of a 2D NLA setup can be found in the documentation of the
%   multirate_mhr_ccpd.m.
%
%   References: 
%   [1] M. Sorensen and L. De Lathauwer, "Multidimensional Harmonic 
%       Retrieval via Coupled Canonical Polyadic Decomposition - Part I:
%       Model and Identifiability", IEEE Transactions on Signal Processing,
%       vol. 65, no. 2, pp. 517-527, 2017.
%   [2] M. Sorensen and L. De Lathauwer, "Multidimensional Harmonic 
%       Retrieval via Coupled Canonical Polyadic Decomposition - Part II:
%       Algorithm and Multirate Sampling", IEEE Transactions on Signal 
%       Processing, vol. 65, no. 2, pp. 528-539, 2017. 

%   Authors:    Mikael Sorensen         
%               Robin Kenis             (Robin.Kenis@kuleuven.be)
%               Lieven De Lathauwer     (Lieven.DeLathauwer@kuleuven.be)
%
%   Version History:
%       - 2021/05/18    RK      Updated version.
%       - 2017/01/01    MS      Initial version.
    
    % Initialization
    R = size(T, 3);
    nb_subula_generators = zeros(2,1);
    subulas_generators = cell(2,1);
    max_generator = zeros(2,1);
    for xy = 1:2
        nb_subula_generators(xy) = length(nla.subulas{xy});
        % Find the powers of the generators in the subulas.
        subulas_generators{xy} = zeros(nb_subula_generators(xy), 1);
        for n = 1:nb_subula_generators(xy)
            subulas_generators{xy}(n) = nla.subulas{xy}{n}(2) - nla.subulas{xy}{n}(1);
        end
        max_generator(xy) = max(subulas_generators{xy}); % Largest subula generator
    end
    generators_phase = zeros(R, 2);
    
    % Construct cell with submatrices per generator
    C = cell([R, nb_subula_generators.']);
    for r = 1:R
        for m = 1:nb_subula_generators(1)
            [~,subula_idx_x] = intersect(nla.sensors{1}, nla.subulas{1}{m} , ...
                                         'stable'); 
            for n = 1:nb_subula_generators(2)
                [~,subula_idx_y] = intersect(nla.sensors{2}, nla.subulas{2}{n} , ...
                                             'stable'); 
                C{r, m, n} = T(subula_idx_x, subula_idx_y, r);
            end
        end
    end
    
    for xy = 1:2
        phi_max = max_generator(xy);
        % Construct the polynomial needed to solve for the x-generators
        for r = 1:R
            poly_coeff_x = zeros(2*phi_max+1,1);
            for m = 1:nb_subula_generators(xy)
                phi = subulas_generators{xy}(m);
                
                beta = 0;
                % mod(xy, 2)+1 is the other generator
                for n = 1:nb_subula_generators(mod(xy, 2)+1)
                    switch xy
                      case 1
                        Ccur = C{r, m, n};
                      case 2
                        Ccur = C{r, n, m}.';
                    end
                    beta = beta + sum(conj(Ccur(1:end-1, :)).*Ccur(2:end, :), 'all');
                end

                for k = 0:(phi_max-phi)
                    for p = 0:2*phi
                        % Power of current polynomial term.
                        idx = 2*phi-p+2*k+1; 
                        if p ~=0
                            % -p*t^(idx+1)
                            poly_coeff_x(idx+1) = poly_coeff_x(idx+1) - ...
                                real(beta)*nchoosek(2*phi,p) ...
                                *nchoosek(phi_max-phi,k) ...
                                *p*cos( ((2*phi-p)*pi)/2);
                        end
                        if p ~= 2*phi
                            % (2n-p)*t^(idx-1)
                            poly_coeff_x(idx-1) = poly_coeff_x(idx-1) + ...
                                real(beta)*nchoosek(2*phi,p) ...
                                *nchoosek(phi_max-phi,k)*...
                                (2*phi-p)* ...
                                cos(((2*phi-p)*pi)/2);
                        end
                    end
                end

                % Part of sum starting with Im(beta).
                for k = 0:(phi_max-phi)
                    for p = 0:2*phi
                        % Power of current polynomial term.
                        idx = 2*phi-p+2*k+1;
                        if p ~=0
                            % -q*t^(idx+1)
                            poly_coeff_x(idx+1) = poly_coeff_x(idx+1) - ...
                                imag(beta)*nchoosek(2*phi,p)*...
                                nchoosek(phi_max-phi,k)*...
                                p*sin( ((2*phi-p)*pi)/2);
                        end
                        if p ~= 2*phi
                            % (2n-q)*t^(idx-1)
                            poly_coeff_x(idx-1) = poly_coeff_x(idx-1) +...
                                nchoosek(2*phi,p)*...
                                nchoosek(phi_max-phi,k)*...
                                imag(beta)*(2*phi-p)*...
                                sin(((2*phi-p)*pi)/2);
                        end
                    end
                end
            end

            % Compute roots of polynomial
            phase_est = -2*atan(roots((poly_coeff_x)));

            % Find the polynomial root that corresponds to the generator as 
            % the minimum of cost function f_c.
            nb_roots = length(phase_est);
            f_c = zeros(nb_roots, 1);
            generators = exp(1i * phase_est);

            % Iterate over all roots. 
            for root = 1:nb_roots
                gen = generators(root);
                % Iterate over all subula generators.
                for m = 1:nb_subula_generators(xy)
                    % iterate over the generators for the other variable
                    for n = 1:nb_subula_generators(mod(xy, 2)+1)
                        switch xy
                          case 1
                            Ccur = C{r, m, n};
                          case 2
                            Ccur = C{r, n, m}.';
                        end
                        % Vandermonde vector corresponding to subula m of
                        % generator n.
                        C1 = Ccur(1:end-1, :);
                        Cx = Ccur(2:end, :);
                        % Upper part of Vandermonde vector times generator
                        % should be equal to the lower part of this 
                        % Vandermonde vector.
                        f_c(root) = f_c(root) + frob(C1*gen^subulas_generators{xy}(m)-Cx)^2;
                    end
                end
            end

            % Find generator angle as the minimum of f_c
            [~, min_idx] = min(f_c);   
            generators_phase(r, xy) = phase_est(min_idx);
        end    
    end
    % Compute the unit generators with the estimated phases
    generators = exp(1i*generators_phase);
end