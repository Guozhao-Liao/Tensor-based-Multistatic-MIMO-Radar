function [U_fac, generator_phase, generator,relerr] = ccpd_jevd(tensor,R,varargin)
%% An algebraic algorithm for computing coupled CPD with Vandermonde Structured factor matrices
%% Inputs:
% tensor :  a cell containing M data tensors admitting a coupled CPD, each
% CPD has two slices in the second mode.
% R: Coupled rank of input tensors

%% Outputs:
% F: if only return F are used, return the coupled factor matrix.
% U_fac: a 1 x M cell that contains C-CPD factor matrices for each tensor;
%        the mth cell is another 1 x N(m) cell containing the factor matrices of tensor{m}
%        N is a 1 x M vector with the mth entry being the order of tensor{m}
% relerr: a 1 x M cell that contains the relative fitting error to each data tensor;

%% Compress the last mode to R via coupled tensor compression
tensor = reshape(tensor,[],1);
M = length(tensor);
M1 = length(tensor);
vdm_ten = tensor(1:M);
p = inputParser;
validScalarPosNum = @(x) isnumeric(x) && isscalar(x) && (x >= 0);
p.addOptional('OnlyReturnF', true);
p.addOptional('AddIdentityI', true);
p.addOptional('Compression', true);
p.addOptional('lambda', 1, validScalarPosNum);
p.parse(varargin{:});
fn = [fieldnames(p.Results); fieldnames(p.Unmatched)];
data = [struct2cell(p.Results); struct2cell(p.Unmatched)];
lambda = p.Results.lambda;
options = cell2struct(data, fn);

relerr_vdm = zeros(1,M1);
relerr = zeros(1,M);
if options.Compression
        [ten_cpr,U_cpr_3] = f_cpl_cpr(tensor,R);
        vdm_ten_cpr = ten_cpr(1:M1);
else
    U_cpr_3 = eye(R);
    vdm_ten_cpr = tensor;
end

core = [];
N = zeros(1,M);
if ~isempty(vdm_ten_cpr)
    %% Transfer each Vandermode structured mode of Vandermonde structured tensors into a core tensor whose frontal slices together admit a joint EVD
    vdm_ten_sz = cell(1,M1);
    vdm_N = zeros(1,M1);
    vdm_order = zeros(1,M1);
    ndm_mode = cell(1,M1);
    for mm = 1:M1
        vdm_ten_sz{mm} = size(vdm_ten_cpr{mm});  
        vdm_N(mm) = length(vdm_ten_sz{mm});
        vdm_mode{mm} = [2];    %%
        vdm_order(mm) = length(vdm_mode{mm});
        ndm_mode{mm} = setdiff(1:vdm_N(mm),vdm_mode{mm});
        t_core = f_vdm2core(vdm_ten_cpr{mm},R,vdm_ten_sz{mm},vdm_N(mm),vdm_mode{mm},ndm_mode{mm},vdm_order(mm));
        core = cat(3,core,t_core);
    end
    N(1:M1) = vdm_N;
end

%% Joint EVD
if options.AddIdentityI
    if options.lambda
    core(:,:,end+1) = lambda*eye(R);
    else  
    core(:,:,end+1) = eye(R);
    end
end

[eig_fac,~] = cpd_gevd(core,R);    
[eig_fac,~] = cpd3_sgsd(core,eig_fac); 

A_fac = eig_fac{1};
for rr = 1:R
    A_fac(:,rr) = A_fac(:,rr)/norm(A_fac(:,rr));
end
C_cpr = inv(A_fac.');   
C = U_cpr_3 / (A_fac.');
if options.OnlyReturnF
     U_fac= inv(C.');
    generator_phase = [];
    generator = [];
    relerr = [];
else
%%
if ~isempty(vdm_ten_cpr)
    t_core = core(:,:,1:sum(vdm_order));
    t_core = reshape(t_core,R^2,[]);    
    t_core = ((A_fac'*A_fac).*(C_cpr'*C_cpr)\(kr(C_cpr,A_fac)') * t_core).'; % sum(vdm_order) x R
    offset = 0;
    UTU = cell(1,M1);
    vdm_kr = UTU;
    t_seq = cell(1,M1);
    t_vdm_ten = cell(1,M1);
    t_vdm_sz = cell(1,M1);
    U_vdm = cell(1,M1);
    non_vdm_kr = cell(1,M1);
    idx = 1;
    for mm = 1:M1
        t_seq{mm} = [vdm_mode{mm},vdm_N(mm),ndm_mode{mm}(1:end-1)];
        t_vdm_ten{mm} = permute(vdm_ten_cpr{mm},t_seq{mm});
        t_vdm_sz{mm} = vdm_ten_sz{mm}(t_seq{mm});
        UTU{mm} = ones(R,R);
        t_mtx = t_core(offset+1:offset+vdm_order(mm),:);
        offset = offset + vdm_order(mm);
        for vv = 1:vdm_order(mm)
            t_angle = angle(t_mtx(vv,:));
            z = exp(1i*t_angle);
            t_amp = t_mtx(vv,:)./z;
            U_vdm{mm}{vv} = f_vdm(z, t_vdm_sz{mm}(vv),t_amp);
            UTU{mm} = UTU{mm}.*(U_vdm{mm}{vv}'*U_vdm{mm}{vv});
            generator_phase(:,idx)=t_angle.';
            generator(:,idx)=z.';
            idx=idx+1;
        end
        U_vdm{mm}{vdm_order(mm)+1} = C_cpr;
        if length(ndm_mode{mm}) > 1
            sz_vdm = prod(t_vdm_sz{mm}(1:vdm_order(mm)));
            sz_ndm = prod(t_vdm_sz{mm}(vdm_order(mm)+1:end));
            t_ten = reshape(t_vdm_ten{mm},[sz_vdm*R,sz_ndm/R]);
            %
            vdm_kr{mm} = kr(U_vdm{mm}{vdm_order(mm):-1:1});
            vdm_kr{mm} = kr(C_cpr,vdm_kr{mm});
            UTU{mm} = UTU{mm}.*(C_cpr'*C_cpr);
            non_vdm_kr{mm} = ((UTU{mm}\(vdm_kr{mm}'))*t_ten).';
            %
            t_sz = t_vdm_sz{mm}(vdm_order(mm)+2:end);
            t_mtx = non_vdm_kr{mm};
            t_ind = vdm_order(mm)+2;
            while length(t_sz) > 1
                sz_1 = t_sz(1);
                sz_r = prod(t_sz(2:end));
                [U_vdm{mm}{t_ind},U_r] = f_colwise_rank1(t_mtx,sz_1,sz_r);
                t_sz(1) = [];
                t_mtx = U_r;
                t_ind = t_ind + 1;
            end
            U_vdm{mm}{t_ind} = t_mtx;
        else
            sz_vdm = prod(t_vdm_sz{mm}(1:vdm_order(mm)));
            t_ten = reshape(t_vdm_ten{mm},sz_vdm,R);
            vdm_kr{mm} = kr(U_vdm{mm}{vdm_order(mm):-1:1});
            t_C = ((UTU{mm}\(vdm_kr{mm}'))*t_ten).';
            co = diag(mean(t_C./C_cpr,1));
            C_cpr = C_cpr * co;
            C = U_cpr_3 * C_cpr;
        end
        seq1 = zeros(1,vdm_N(mm));
        seq1(t_seq{mm}) = 1:vdm_N(mm);
        U_vdm{mm} = U_vdm{mm}(seq1);
        U_vdm{mm}{vdm_N(mm)} = C;
        relerr_vdm(mm) = f_relerr(U_vdm{mm},vdm_ten{mm});
    end
    U_fac = cell(1,M);
    U_fac(1:M1) = U_vdm;
    relerr(1:M1) = relerr_vdm;
end
end
end

function core = f_vdm2core(tensor,R,sz,N,vdm_mode,non_vdm_mode,vdm_order)
%% This function transfers each Vandermonde structure mode of tensor into a core whose frontal slices together admit a joint EVD
seq = [vdm_mode,non_vdm_mode];   
T1 = permute(tensor,seq);   % 
sz = sz(seq);
core = zeros(R,R,vdm_order);  
t_mtx = [];
t_sz = zeros(vdm_order,1);  
for vv = 1:vdm_order
    order1 = setdiff(1:N-1,vv);
    new_order = [order1,vv,N];  
    mtx = permute(T1,new_order);
    sz_1 = prod(sz(order1));
    mtx = reshape(mtx,[sz_1,sz(vv)*sz(N)]);  
    if sz_1 > R   
        [~,t_s,t_v] = f_svd(mtx,R);
        mtx = t_s * t_v';
        t_sz(vv) = R;
    else
        t_sz(vv) = sz_1;
    end
    mtx = reshape(mtx,[t_sz(vv),sz(vv),sz(N)]); 
    mtx = reshape(mtx,[t_sz(vv)*sz(vv),sz(N)]);  
    t_mtx = [t_mtx;mtx];    
end
offset = 0;
for vv = 1:vdm_order
    mtx = t_mtx(offset+1:offset+t_sz(vv)*sz(vv),:);  
    U1 = mtx(1:(sz(vv)-1)*t_sz(vv),:);    
    U2 = mtx((t_sz(vv)+1):sz(vv)*t_sz(vv),:);  
    core(:,:,vv) = pinv(U1)*U2;    
    offset = offset + t_sz(vv)*sz(vv);
end
end

function [ten,V] = f_cpl_cpr(ten,Q)
% Compress the last mode of input coupled tensors to Q
M = length(ten);
sz = cell(M,1);
N = zeros(M,1);
T_mtx = [];
for mm = 1:M
    sz{mm} = size(ten{mm});
    N(mm) = length(sz{mm});
    if mm == 1
        K = sz{mm}(end);
    end
    T_mtx = [T_mtx;reshape(ten{mm},[prod(sz{mm}(1:end-1)),K])];
end
[t_u,t_s,V] = f_svd(T_mtx,Q);
V = conj(V);
T_mtx = t_u * t_s;
offset = 0;
for mm = 1:M
    sz{mm}(end) = Q;
    row_range = offset+1 : offset+prod(sz{mm}(1:end-1));
    offset = offset + prod(sz{mm}(1:end-1));
    ten{mm} = T_mtx(row_range,:);
    ten{mm} = reshape(ten{mm},sz{mm});
end
end
function U = f_vdm(generator, dim, phase_offset)
R = numel(generator);
U = ones(dim,R);
U(1,:) = phase_offset;
for ii = 2:dim
    U(ii,:) = U(ii-1,:).*generator;
end
end
function [U_l,U_r] = f_colwise_rank1(mtx, sz_l, sz_r)
R = size(mtx,2);
U_l = zeros(sz_l,R);
U_r = zeros(sz_r,R);
for rr = 1:R
    t_mtx = reshape(mtx(:,rr),[sz_l,sz_r]);
    [U,S,V] = svd(t_mtx);
    U_l(:,rr) = U(:,1);
    U_r(:,rr) = S(1,1)*conj(V(:,1));
end
end
function fval = f_relerr(U, tensor)
resten = cpdgen(U) - tensor;
fval = sqrt((resten(:)'*resten(:))/(tensor(:)'*tensor(:)));
end
function [U,S,V] = f_svd(mtx,R)
sz = size(mtx);
if sz(1) == sz(2)
    [U,S,V] = svd(mtx);
    U = U(:,1:R);S = S(1:R,1:R);V = V(:,1:R);
elseif sz(1) < sz(2)
    t_mtx = mtx * mtx';
    [U,S,~] = svd(t_mtx);
    U = U(:,1:R);
    S = sqrt(S(1:R,1:R));
    V = (S\U')*mtx;
    V = V';
else
    t_mtx = mtx'*mtx;
    [V,S,~] = svd(t_mtx);
    V = V(:,1:R);
    S = sqrt(S(1:R,1:R));
    U = mtx*V/S;
end
end