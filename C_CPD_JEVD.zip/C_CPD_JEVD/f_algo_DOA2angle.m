
function  [theta_phi_angle] = f_algo_DOA2angle(DOA,rad)

% rad = 0;
M = size(DOA,1); 
theta_phi_angle = cell(M,1);
for i = 1:M
    DOA_matrix = DOA{i};
    R = size(DOA_matrix,2);

    for r = 1:R
      [sita, phai, ~] = f_Angle_Judgment(DOA_matrix(:,r));  
      theta_phi_angle{i}(r,1) =   sita;
      theta_phi_angle{i}(r,2) =   phai;   
    end
  
end 


end


function [sita_angle, phai_angle, DOA] = f_Angle_Judgment(DOA)
if DOA(3) < 0
    DOA = -DOA;
end
phai = acos(DOA(3));
sp = sin(phai);cp = cos(phai);
cs = DOA(1)/sp;
ss = DOA(2)/sp;

if ss >= 0 % 
    sita = acos(cs);
else
    if cs >= 0 % 
        sita = 2*pi + asin(ss);
    else % 
        sita = atan(ss/cs) + pi;
    end
end
sita_angle = sita/pi*180;
phai_angle = phai/pi*180;
end

