

function perm_alg = f_rotation_alignment(tgt_pos_alg_ture,tgt_pos_alg,R)

for i = 1:R
   distance_matrix(:,i) = sum(abs(repmat(tgt_pos_alg_ture(:,i),[1,R])-tgt_pos_alg),1);
end

perm_alg = zeros(R,R);
true_index_r  = 1:R;
true_index_c  = 1:R;
for i = 1:R
   
   [r,c] = find(distance_matrix == min(distance_matrix,[],'all'));
   %% true_index
   r_index = r(1);
   c_index = c(1);
   perm_alg(true_index_r(r_index),true_index_c(c_index)) = 1;
distance_matrix(r_index,:) = [];   
distance_matrix(:,c_index) = [];
 true_index_r(r_index) = [];
true_index_c(c_index) = [];  
end


end